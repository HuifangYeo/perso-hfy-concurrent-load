package com.activeviam.training.test;

import java.io.Serializable;

public class PojoVO implements Serializable {

	private static final long serialVersionUID = 3725419544052070456L;
	private String stringField1;
	private String stringField2;
	private String stringField3;
	private String stringField4;
	private String stringField5;
	private String stringField6;
	private String stringField7;
	private String stringField8;
	private String stringField9;
	private String stringField10;
	private long longField1;
	private long longField2;
	private long longField3;
	private long longField4;
	private long longField5;
	private long longField6;
	private long longField7;
	private long longField8;
	private long longField9;
	private long longField10;
	
	public PojoVO(String stringField1, String stringField2, String stringField3, String stringField4,
			String stringField5, String stringField6, String stringField7, String stringField8, String stringField9,
			String stringField10, long longField1, long longField2, long longField3, long longField4,
			long longField5, long longField6, long longField7, long longField8, long longField9,
			long longField10) {
		super();
		this.stringField1 = stringField1;
		this.stringField2 = stringField2;
		this.stringField3 = stringField3;
		this.stringField4 = stringField4;
		this.stringField5 = stringField5;
		this.stringField6 = stringField6;
		this.stringField7 = stringField7;
		this.stringField8 = stringField8;
		this.stringField9 = stringField9;
		this.stringField10 = stringField10;
		this.longField1 = longField1;
		this.longField2 = longField2;
		this.longField3 = longField3;
		this.longField4 = longField4;
		this.longField5 = longField5;
		this.longField6 = longField6;
		this.longField7 = longField7;
		this.longField8 = longField8;
		this.longField9 = longField9;
		this.longField10 = longField10;
	}
	
	@Override
	public String toString() {
		return "PojoVO [stringField1=" + stringField1 + ", stringField2=" + stringField2 + ", stringField3="
				+ stringField3 + ", stringField4=" + stringField4 + ", stringField5=" + stringField5 + ", stringField6="
				+ stringField6 + ", stringField7=" + stringField7 + ", stringField8=" + stringField8 + ", stringField9="
				+ stringField9 + ", stringField10=" + stringField10 + ", longField1=" + longField1 + ", longField2="
				+ longField2 + ", longField3=" + longField3 + ", longField4=" + longField4 + ", longField5="
				+ longField5 + ", longField6=" + longField6 + ", longField7=" + longField7 + ", longField8="
				+ longField8 + ", longField9=" + longField9 + ", longField10=" + longField10 + "]";
	}
	
	public String getStringField1() {
		return stringField1;
	}
	public void setStringField1(String stringField1) {
		this.stringField1 = stringField1;
	}
	public String getStringField2() {
		return stringField2;
	}
	public void setStringField2(String stringField2) {
		this.stringField2 = stringField2;
	}
	public String getStringField3() {
		return stringField3;
	}
	public void setStringField3(String stringField3) {
		this.stringField3 = stringField3;
	}
	public String getStringField4() {
		return stringField4;
	}
	public void setStringField4(String stringField4) {
		this.stringField4 = stringField4;
	}
	public String getStringField5() {
		return stringField5;
	}
	public void setStringField5(String stringField5) {
		this.stringField5 = stringField5;
	}
	public String getStringField6() {
		return stringField6;
	}
	public void setStringField6(String stringField6) {
		this.stringField6 = stringField6;
	}
	public String getStringField7() {
		return stringField7;
	}
	public void setStringField7(String stringField7) {
		this.stringField7 = stringField7;
	}
	public String getStringField8() {
		return stringField8;
	}
	public void setStringField8(String stringField8) {
		this.stringField8 = stringField8;
	}
	public String getStringField9() {
		return stringField9;
	}
	public void setStringField9(String stringField9) {
		this.stringField9 = stringField9;
	}
	public String getStringField10() {
		return stringField10;
	}
	public void setStringField10(String stringField10) {
		this.stringField10 = stringField10;
	}
	public long getlongField1() {
		return longField1;
	}
	public void setlongField1(long longField1) {
		this.longField1 = longField1;
	}
	public long getlongField2() {
		return longField2;
	}
	public void setlongField2(long longField2) {
		this.longField2 = longField2;
	}
	public long getlongField3() {
		return longField3;
	}
	public void setlongField3(long longField3) {
		this.longField3 = longField3;
	}
	public long getlongField4() {
		return longField4;
	}
	public void setlongField4(long longField4) {
		this.longField4 = longField4;
	}
	public long getlongField5() {
		return longField5;
	}
	public void setlongField5(long longField5) {
		this.longField5 = longField5;
	}
	public long getlongField6() {
		return longField6;
	}
	public void setlongField6(long longField6) {
		this.longField6 = longField6;
	}
	public long getlongField7() {
		return longField7;
	}
	public void setlongField7(long longField7) {
		this.longField7 = longField7;
	}
	public long getlongField8() {
		return longField8;
	}
	public void setlongField8(long longField8) {
		this.longField8 = longField8;
	}
	public long getlongField9() {
		return longField9;
	}
	public void setlongField9(long longField9) {
		this.longField9 = longField9;
	}
	public long getlongField10() {
		return longField10;
	}
	public void setlongField10(long longField10) {
		this.longField10 = longField10;
	}
	
	
}
